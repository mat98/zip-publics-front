<!-- apontei o serviço para o nginx dentro do container -->
docker run -p 8080:80 --it --name dockervue dockervue